package apresentacao;


public class Main {

	public static void main(String[] args) {

		Menu menu = new Menu();
		menu.iniciarAvaliacao(8, 16);

	}
}
