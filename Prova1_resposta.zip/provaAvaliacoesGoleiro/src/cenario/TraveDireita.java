package cenario;

public class TraveDireita extends ElementosDoGol{

	public TraveDireita(int posicaoX, int posicaoY, int quadrante) {
		super(posicaoX, posicaoY, quadrante);
		this.simbolo="||";
	}

}
