package cenario;

public class DentroDoGol extends ElementosDoGol {

	public DentroDoGol(int posicaoX, int posicaoY, int quadrante) {
		super(posicaoX, posicaoY, quadrante);
		this.simbolo="_";
	}

}
