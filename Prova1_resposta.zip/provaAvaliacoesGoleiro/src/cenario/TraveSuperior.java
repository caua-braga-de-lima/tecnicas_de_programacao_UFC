package cenario;

public class TraveSuperior  extends ElementosDoGol{

	public TraveSuperior(int posicaoX, int posicaoY, int quadrante) {
		super(posicaoX, posicaoY, quadrante);
		this.simbolo="=";
	}

}
