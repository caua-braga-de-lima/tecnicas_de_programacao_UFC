package cenario;

public class TraveEsquerda extends ElementosDoGol{

	public TraveEsquerda(int posicaoX, int posicaoY, int quadrante) {
		super(posicaoX, posicaoY, quadrante);
		this.simbolo="||";
	}

}
