package cenario;

public class Gaveta  extends ElementosDoGol{

	public Gaveta(int posicaoX, int posicaoY, int quadrante) {
		super(posicaoX, posicaoY, quadrante);
		this.simbolo="[";
	}

}
