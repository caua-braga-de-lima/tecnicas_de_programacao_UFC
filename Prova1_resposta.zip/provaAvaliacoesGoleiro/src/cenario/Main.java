package cenario;

public class Main {

	public static void main(String[] args) {
		
		Gol g= new Gol(8,16);
		g.fabricaDeGol();
		System.out.println(g.imprimirGol());

		
	}

}
