package cenario;

public class ForaDoGol  extends ElementosDoGol{

	public ForaDoGol(int posicaoX, int posicaoY, int quadrante) {
		super(posicaoX, posicaoY, quadrante);
		this.simbolo="@";
	}

}
