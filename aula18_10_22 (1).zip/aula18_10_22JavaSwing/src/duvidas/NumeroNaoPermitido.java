package duvidas;

public class NumeroNaoPermitido extends Exception {

}
