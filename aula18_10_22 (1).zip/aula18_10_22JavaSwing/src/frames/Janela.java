package frames;
 
import javax.swing.*;        
 
public class Janela {

	
	public static void main(String[] args) {
		
		JFrame janela = new JFrame ();
		janela.setSize(800, 600);
		janela.setTitle("Minha primeira janela");
		janela.setVisible(true);
		janela.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
 
  
}
