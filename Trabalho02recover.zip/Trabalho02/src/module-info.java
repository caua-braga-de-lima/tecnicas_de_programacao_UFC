module Trabalho02 {
	requires java.desktop;
}