package penaltyMania;

import javax.swing.JPanel;

public class Main 
{

	public static void main(String[] args) 
	{
		Window game = new Window();
		System.out.println("");
	}
}
