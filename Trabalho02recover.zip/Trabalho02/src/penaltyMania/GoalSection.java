//ENUM SECAO DO GOL - LISTA AS 3 SECOES DO GOL COMO CONSTANTES.

package penaltyMania;
public enum GoalSection 
{
	GOAL,
	POST,
	OUT;

}
