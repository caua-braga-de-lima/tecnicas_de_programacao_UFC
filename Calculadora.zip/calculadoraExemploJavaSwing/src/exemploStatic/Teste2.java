package exemploStatic;

public class Teste2 {

	public void testar() {
		Teste teste= Teste.pegarInstancia();
		System.out.println("2: "+ teste.getNumero());
	}
}
