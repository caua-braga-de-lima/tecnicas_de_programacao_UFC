package exemploEnun;

public class Main {

	public static void main(String[] args) {
		
		ExemploEnum e = new ExemploEnum();
		
		e.testarCarro(TipoCarros.GOL);
	}

}
