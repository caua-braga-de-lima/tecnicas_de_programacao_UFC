package exemploEnun;

public enum TipoCarros {

	UNO,
	FUSCA,
	GOL
}
