package exemplo;

public class Main {

	public static void main(String[] args) {

		Calculadora j = new Calculadora();
	}

}
