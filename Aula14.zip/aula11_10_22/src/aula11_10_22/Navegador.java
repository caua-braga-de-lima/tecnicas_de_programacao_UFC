package aula11_10_22;

public class Navegador {

	
	public void testeDoTocador(IPlay tocador) {
		
		tocador.start();
//		tocador.stop();
//		tocador.next(2);
//		tocador.back(2);
//		tocador.pause();
	
	}
}
