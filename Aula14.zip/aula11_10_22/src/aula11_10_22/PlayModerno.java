package aula11_10_22;

public class PlayModerno extends Play{

	@Override
	public void start() {
		System.out.println("Estou tocando");
		
	}

	@Override
	public void stop() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void next(int quantidade) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void back(int quantidade) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void pause() {
		// TODO Auto-generated method stub
		
	}


}
