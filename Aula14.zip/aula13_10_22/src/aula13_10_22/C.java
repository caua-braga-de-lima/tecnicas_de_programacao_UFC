package aula13_10_22;

public class C {

	public void c() {
		System.out.println("Classe C");
		B b = new B();
//		try {
		b.b();
//		}catch (Exception e) {
//	      e.printStackTrace();
//		}
		System.out.println("c");
	}
}
