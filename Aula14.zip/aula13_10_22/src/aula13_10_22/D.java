package aula13_10_22;

public class D {

	public void d() {
		System.out.println("Classe D");
		C c= new C();
		c.c();
		System.out.println("D");
	}
}
