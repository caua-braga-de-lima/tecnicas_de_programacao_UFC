package aula13_10_22;

public class IngressoJaVendido  extends Exception{

}
